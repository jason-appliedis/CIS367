<?php include '../view/header.php'; ?>
<main>
    <h1>Error</h1>
    <p><?php echo $error; ?></p>
</main>
<?php include '../view/footer.php'; ?>