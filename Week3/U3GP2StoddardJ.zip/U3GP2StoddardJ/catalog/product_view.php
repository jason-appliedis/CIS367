<?php include '../view/header.php'; ?>
<?php include '../view/sidebar.php'; ?>
<section>
    <!-- display product -->
    <?php include '../view/product.php'; ?>
</section>
<?php include '../view/footer.php'; ?>