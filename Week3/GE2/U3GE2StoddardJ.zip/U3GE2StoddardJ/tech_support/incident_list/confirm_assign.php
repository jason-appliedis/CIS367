<?php include '../view/header.php'; ?>



<main>
<h1>Assign Incident</h1>
<p>This incident was assigned to a technician.</p>
<br>
<a href=".">Select Another Incident</a>
</main>

<?php include '../view/footer.php';?>