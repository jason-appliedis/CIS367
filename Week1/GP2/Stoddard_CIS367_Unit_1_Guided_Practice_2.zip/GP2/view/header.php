<?php 
$path = $_SERVER['DOCUMENT_ROOT'];
$mainCssPath = $path . "/Week1/GP2/main.css";
?>
<!DOCTYPE html>
<html>

<head>
    <title>My Guitar Shop</title>
    <style>
        <?php include_once($mainCssPath); ?>
    </style>
</head> 
<!-- the body section -->
<body>
<header><h1>My Guitar Shop</h1></header>
